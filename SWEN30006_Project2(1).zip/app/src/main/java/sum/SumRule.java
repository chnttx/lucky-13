package sum;

import player.Player;

public interface SumRule {
  boolean checkSumEquals13(Player player);
}
